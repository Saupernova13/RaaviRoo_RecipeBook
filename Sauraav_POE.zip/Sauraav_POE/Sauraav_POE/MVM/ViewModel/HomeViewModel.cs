﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sauraav_POE.Core;

namespace Sauraav_POE.MVM.ViewModel
{
    public class HomeViewModel
    {
    }
}
